

	<?php  
    	$featured  =   $this->crud_model->getFeaturedProduct();
    ?>

	<div class="ps-product-list ps-clothings mt-5 cc">
        <div class="ps-container">
          <div class="ps-section__header">
            <h3><?php echo translate('our_category');?></h3>
            <!-- <ul class="ps-section__links">
              <li><a href="">New Arrivals</a></li>
              <li><a href="">Best seller</a></li>
              <li><a href="">Must Popular</a></li>
              <li><a href="">View All</a></li>
            </ul> -->
          </div>
          <div class="col-md-12">
            <div class="row"><?php // echo '<pre>'; print_r($categories); echo '</pre>';
                if($categories){ foreach($categories as $row){ 
                    if($row['image'] != NULL || $row['image'] != ''){ $image = 'uploads/category_image/'.$row['image']; }else{ $image = 'uploads/others/photo_default.png'; } ?>
                    <div class="col-6 col-md-2">
                        <div class="indus_box">
                        <div>
                            <a href="<?php echo base_url('home/category/'.$row['category_id'])?>">
                                <img src="<?php echo $image?>" alt="<?php echo $row['category_name']?>" />
                            </a>
                        </div>
                        <h4><?php echo $row['category_name']?></h4>
                        </div>
                    </div><?php
                } } ?>
                </div>
            </div>
        </div>
     </div>
     
     
     <div class="ps-product-list ps-clothings mt-5">
        <div class="ps-container">
          <div class="ps-section__header">
            <h3><?php echo translate('our_industries');?></h3>
            </div>
            <div class="col-md-12">
                <div class="row"><?php
                    if($brands){ foreach($brands as $row){ 
                    if(file_exists(FCPATH.'uploads/brand_image/brand_'.$row->brand_id.'.png')){ $image = 'uploads/brand_image/brand_'.$row->brand_id.'.png'; }
                    else{ $image = 'uploads/others/photo_default.png'; } ?>
                    <div class="col-6 col-md-2">
                        <div class="indus_box">
                        <div><img src="<?php echo base_url($image)?>" alt="<?php echo $row->name?>" /></div>
                        <h4><?php echo $row->name?></h4>
                        </div>
                    </div><?php
                } } ?>
                </div>
            </div>
        </div>
    </div>